<?php
include "connection.php";
	$x=$_REQUEST['customerid'];
	$query="delete from customer where customerid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=display.php" ); 
	echo '<h3>Records deleted successfully</h3>';
?>