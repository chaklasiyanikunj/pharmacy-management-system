<?php
include "connection.php";
	$x=$_REQUEST['medicalid'];
	$query="delete from medicalstore where medicalid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managemedicalstore.php" ); 
	echo '<h3>Records deleted successfully</h3>';
?>