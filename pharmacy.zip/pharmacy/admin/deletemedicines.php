<?php
include "connection.php";
	$x=$_REQUEST['medicinesid'];
	$query="delete from medicines where medicinesid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managemedicines.php" ); 
	echo '<h3>Records deleted successfully</h3>';
?>