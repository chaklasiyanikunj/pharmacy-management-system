<?php
include "connection.php";
	$x=$_REQUEST['syrupid'];
	$query="delete from syrup where syrupid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managesyrup.php" ); 
	echo '<h3>Records deleted successfully</h3>';
?>