<?php 
	include "connection.php";
	echo "<br><br><br>";
	echo "<table border='1' style='width:40%;float:left;margin-left:2%'>";
	echo "<Tr><th>customerid</th><th>UserName</th><th>Email</th>
	<th>Password</th><th>Age</th><th>Update</th><th>Delete</th></tR>";
	
	$sql=mysqli_query($con,"select * from customer");
	//$i=1;
	while($res=mysqli_fetch_assoc($sql))
	{
	$id=$res['customerid'];
	$username=$res['username'];	
	$email=$res['email'];
	$pass=$res['password'];
	$age=$res['age'];	
	
	echo "<tr>";
	echo "<td>".$id."</td>";
	echo "<td>".$username."</td>";
	echo "<td>".$email."</td>";
	echo "<td>".$pass."</td>";
	echo "<td>".$age."</td>";
	//echo "<td></td>";
	
	echo "<td><a href='update.php?customerid=$id'>Update</a></td>";
	echo "<td><a href='delete.php?customerid=$id'>Delete</a></td>";
	
	echo "</tr>";
	//$i++;
	
}
	echo "</table>";
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.con{position:absolute;
margin-top:50px;
width:74%;
background-color:#C0C1FA;
left:140px;
}
a{
	color:yellow;
}
input
{
font-size:50px;
}
body {
      position: relative; 
  }
  .affix {
      top:0;
      width: 100%;
      z-index: 9999 !important;
  }
  .navbar {
      margin-bottom: 0px;
  }

  .affix ~ .container-fluid {
     position: relative;
     top: 50px;
  }
  #section1 {padding-top:50px;height:500px;color: #fff; background-color: #1E88E5;}
  #section2 {padding-top:50px;height:500px;color: #fff; background-color: #673ab7;}
  #section3 {padding-top:50px;height:500px;color: #fff; background-color: #ff9800;}
  #section41 {padding-top:50px;height:500px;color: #fff; background-color: #00bcd4;}
  #section42 {padding-top:50px;height:500px;color: #fff; background-color: #009688;}
.container {
    position: relative;
    width: 100%;
    max-width: 4000px;
}

.container img {
    width: 3000px;
    height: 650px;
}

.container .btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container .btn:hover {
    background-color: black;
}
  </style>
</head>

<body bgcolor="#CCCCCC">
<nav class="navbar navbar-inverse" data-spy="affix">
  <div class="container-fluid">
	<div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">PhaemacyManagementSystem</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="menu.php">Home</a></li>
          <li><a href="managecustomer.php">ManageCustomer</a></li>
		  <li><a href="display.php">Managemedicalstore</a></li>
          <li><a href="#section3">SearchDoctor</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Search<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="medicine.php">Medicine</a></li>
              <li><a href="syrup.php">Syrup</a></li>
            </ul>
          </li>
	<li><a href="feedback.php">FeedBack</a></li>
	<li><a href="help.php">Help</a></li>
		<li><a href="#logout">LogOut</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>  
</body>
</html>