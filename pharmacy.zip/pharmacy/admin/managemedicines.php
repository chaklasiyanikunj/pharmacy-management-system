<?php 
	include "connection.php";
	echo "<br><br><br>";
	if (session_status() == PHP_SESSION_NONE) 
 {
        session_start();
		//echo "Hello";
		
 }
     if(!isset($_SESSION['email']))
	 {
		 header("location:..\login.php");
	 }
	echo "<table border='1' style='width:40%;float:left;margin-left:2%'>";
	echo "<Tr><th>medicinesid</th><th>medicinesname</th>
	<th>medicinestype</th><th>medicinescost</th><th>medicinescompany</th><th>medicinesdescription</th><th>update</th><th>delete</th></tR>";
	
	$sql=mysqli_query($con,"select * from medicines");
	//$i=1;
	while($res=mysqli_fetch_assoc($sql))
	{
	$id= $res['medicinesid'];
	$mname = $res['medicinesname'];
	$mtype = $res['medicinestype'];
	$mcost = $res['medicinescost'];
	$mcompany = $res['medicinescompany'];
	$mdescription = $res['medicinesdescription'];	
	
	echo "<tr>";
	echo "<td>".$id."</td>";
	echo "<td>".$mname."</td>";
	echo "<td>".$mtype."</td>";
	echo "<td>".$mcost."</td>";
	echo "<td>".$mcompany."</td>";
	echo "<td>".$mdescription."</td>";
	//echo "<td></td>";
	
	echo "<td><a href='updatemedicines.php?medicinesid=$id'>Update</a></td>";
	echo "<td><a href='deletemedicines.php?medicinesid=$id'>Delete</a></td>";
	
	echo "</tr>";
	//$i++;
	
}
	echo "</table>";
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.con{position:absolute;
margin-top:50px;
width:74%;
background-color:#C0C1FA;
left:140px;
}
a{
	color:yellow;
}
input
{
font-size:50px;
}
body {
      position: relative; 
  }
  .affix {
      top:0;
      width: 100%;
      z-index: 9999 !important;
  }
  .navbar {
      margin-bottom: 0px;
  }

  .affix ~ .container-fluid {
     position: relative;
     top: 50px;
  }
.container {
    position: relative;
    width: 100%;
    max-width: 4000px;
}

.container img {
    width: 3000px;
    height: 650px;
}

.container .btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container .btn:hover {
    background-color: black;
}
  </style>
</head>

<body bgcolor="#CCCCCC">
<nav class="navbar navbar-inverse" data-spy="affix">
  <div class="container-fluid">
	<div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">PhaemacyManagementSystem</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="managecustomer.php">ManageCustomer</a></li>
	  <li><a href="managemedicalstore.php">Managemedicalstore</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">manage<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="managemedicines.php">Medicine</a></li>
              <li><a href="managesyrup.php">Syrup</a></li>
            </ul>
		<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Add<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="medicineregister.php">Medicine</a></li>
              <li><a href="syrupregister.php">Syrup</a></li>
            </ul>
          </li>
	<li><a href="help.php">Help</a></li>
	<li><a href="logout.php">LogOut</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>  
</body>
</html>