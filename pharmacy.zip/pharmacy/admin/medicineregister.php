<?php 
include('connection.php');
extract($_REQUEST);

if(isset($_POST['save']))
{

	$mname = $_POST['medicinesname'];
	$mtype = $_POST['medicinestype'];
	$mcost = $_POST['medicinescost'];
	$mcompany = $_POST['medicinescompany'];
	$mdescription = $_POST['medicinesdescription'];
	
	//$sql = "insert into customer(username,email,password,confirmpassword) values('$uname','$eml','$pswd','$pswd2')";
	//mysqli_query($con,$sql);
	
	$query = "select * from medicines where medicinestype='$mtype' ";
	$sql = mysqli_query($con,$query);
	
	//select record
	$row = mysqli_num_rows($sql);	
	if($row==1)
	{
		echo "<h3 style='color:red;margin-left:100px'>This email alredy exists</h3>";
	}
	else
	{
		$query = "insert into medicines(medicinesname,medicinestype,medicinescost,medicinescompany,medicinesdescription) values('$mname','$mtype',$mcost,'$mcompany','$mdescription')";
		if(mysqli_query($con,$query))
		{
			//echo "<h3 style='color:blue;margin-left:100px'>Records Saved Successfully <br></h3>";	
		}
		else
		{
			echo "Some error while executing query";
		}
	}
}
?>
<html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="demo.css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" type="text/css" href="animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
</script>	<script type="text/javascript" src="../../../validation/jquery-1.10.2.js">
</script>
<script type="text/javascript" src="../../../validation/validate.js"></script>
<script>
		
	$("document").ready(function(){

	$("#mname").blur(function(){
    //alert("This input fname.");
	test_name("#mname","#msgfname");
});
		$("#save").click(function(){
			var mname,mtype,mcost,mcompany,mdescription;
			
			mname = test_name("#mname","#msgmname");
			mtype = test_name("#mtype","#msgmtype");
			mcost = test_num("#mcost","msgmcost");
			mcompany = test_name("#mcompany","#msgmcompany");
			mdescription = test_name("#mdescription","#msgmdescription");
			//alert(fname);
			
			if(mname == true && mtype == true && mcost == true && mcompany==true && mdescription==true)
			{
				return true;
				
			}
			else
			{
				return false;
			}
			
		});
	
	});
</script>
	<style>
	</style>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo">
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1>Add Medicines</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >Medicines name</label>
                                    <input id="mname" name="medicinesname" rtype="text" placeholder="Paracetamol 325mg Tab" />
                                <span id="msgmname"></span>
								</p>
                                <p> 
                                    <label for="emailsignup" class="youmail" >Medicines type</label>
                                    <input id="mtype" name="medicinestype" placeholder="Antibiotics"/> 
                                <span id="msgmtype"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >Medicines cost</label>
                                    <input id="mcost" name="medicinescost"  type="text" placeholder="60"/>
                                <span id="msgmcost"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Medicines company </label>
                                    <input id="mcompany" name="medicinescompany"  type="text" placeholder="shipla" />
                                <span id="msgmcompany"></span>
								</p>
								 <p> 
                                 <label for="usernamesignup" class="uname" >Medicines description</label>
                                     <input id="mdescription" name="medicinesdescription"  type="text" placeholder="one-one-one" />
                                <span id="msgmdescription"></span>
								</p>
                                <p class="signin button"> 
									<input id="save" type="submit" value="ADD" name="save"/> 
								</p>
</p>
      
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>