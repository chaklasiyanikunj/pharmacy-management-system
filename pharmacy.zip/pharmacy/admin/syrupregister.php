<?php 
include('connection.php');
extract($_REQUEST);

if(isset($_POST['save']))
{

	$sname = $_POST['syrupname'];
	$stype = $_POST['syruptype'];
	$scost = $_POST['syrupcost'];
	$scompany = $_POST['syrupcompany'];
	$sdescription = $_POST['syrupdescription'];
	
	//$sql = "insert into customer(username,email,password,confirmpassword) values('$uname','$eml','$pswd','$pswd2')";
	//mysqli_query($con,$sql);
	
	$query = "select * from syrup where syruptype='$stype' ";
	$sql = mysqli_query($con,$query);
	
	//select record
	$row = mysqli_num_rows($sql);	
	if($row==1)
	{
		echo "<h3 style='color:red;margin-left:100px'>This email alredy exists</h3>";
	}
	else
	{
		$query = "insert into syrup(syrupname,syruptype,syrupcost,syrupcompany,syrupdescription) values('$sname','$stype',$scost,'$scompany','$sdescription')";
		if(mysqli_query($con,$query))
		{
			//echo "<h3 style='color:blue;margin-left:100px'>Records Saved Successfully <br></h3>";	
		}
		else
		{
			echo "Some error while executing query";
		}
	}
}
?>
<html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="demo.css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" type="text/css" href="animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	</script>	<script type="text/javascript" src="../../../validation/jquery-1.10.2.js">
</script>
<script type="text/javascript" src="../../../validation/validate.js"></script>
<script>
		
	$("document").ready(function(){

	$("#sname").blur(function(){
    //alert("This input fname.");
	test_name("sname","#msgsname");
});
		$("#save").click(function(){
			var sname,stype,scost,scompany,sdescription;
			
			sname = test_name("#sname","#msgsname");
			stype = test_name("#stype","#msgstype");
			scost = test_num("#scost","msgscost");
			scompany = test_name("#scompany","#msgscompany");
			sdescription = test_name("#sdescription","#msgsdescription");
			//alert(fname);
			
			if(mname == true && mtype == true && mcost == true && mcompany==true && mdescription==true)
			{
				return true;
				
			}
			else
			{
				return false;
			}
			
		});
	
	});
</script>
	<style>
	</style>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo">
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1>Add syrup</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >syrup name</label>
                                    <input id="sname" name="syrupname" required="required" type="text" placeholder="Robitussin Dry Cough" />
                                 <span id="msgsname"></span>
								</p>
                                <p> 
                                    <label for="emailsignup" class="youmail" >syrup type</label>
                                    <input id="stype" name="syruptype" placeholder="cough"/> 
								 <span id="msgstype"></span>
							   </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >syrup cost</label>
                                    <input id="scost" name="syrupcost" required="required" type="text" placeholder="85"/>
                                 <span id="msgscost"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >syrup company </label>
                                    <input id="scompany" name="syrupcompany" required="required" type="text" placeholder="torex"/>
                                 <span id="msgscompany"></span>
								</p>
								 <p> 
                                 <label for="usernamesignup" class="uname" >syrup description</label>
                                     <input id="sdescription" name="syrupdescription" required="required" type="text" placeholder="one-one-one" />
								 <span id="msgsdescription"></span>
							   </p>
                                <p class="signin button"> 
									<input id="save" type="submit" value="ADD" name="save"/> 
								</p>
</p>
      
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>