<?php
include "connection.php";
if(isset($_POST['save']))
{
	session_start();
	$x=$_SESSION['id'];
	$u=$_POST['usernamesignup'];
	$e=$_POST['emailsignup'];
	$pass=$_POST['passwordsignup'];
	$a=$_POST['agesignup'];
	$query="update customer SET username='$u',email='$e',password='$pass',age=$a where customerid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managecustomer.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}

?>