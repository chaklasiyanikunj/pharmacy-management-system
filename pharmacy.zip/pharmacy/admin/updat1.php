<?php
include "connection.php";
if(isset($_POST['save']))
{
	session_start();
	$x=$_SESSION['id'];
	
	$u=$_POST['usernamesignup'];
	$e=$_POST['emailsignup'];
	$pass=$_POST['passwordsignup'];
	$c=$_POST['citysignup'];
	$query="update medicalstore SET username='$u',email='$e',password='$pass',city='$c' where medicalid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managemedicalstore.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}

?>