<?php 
include('connection.php');
session_start();
$_SESSION['id']=$_REQUEST['customerid'];
$x=$_SESSION['id'];
$query=mysqli_query($con,"select * from customer where customerid='$x'");
$res=mysqli_fetch_assoc($query);

extract($res);

extract($_REQUEST);
	
	$id=$res['customerid'];
	$username=$res['username'];	
	$email=$res['email'];
	$pass=$res['password'];
	$age=$res['age'];
	
	
//$qua=implode(",",$chk);
	/*if($img=="")
	
	$query="update users SET name='$n',email='$e',password='$pass',mobile='$m',address='$adds',gender='$gen',qualificaction='$qua',state='$state',dob='$dob' where user_id='$x'";
	mysqli_query($con,$query);
	}
	else
	{
	//delete old pic
	unlink("image/$email/$pic");
	move_uploaded_file($_FILES['pic']['tmp_name'],"image/$email/".$_FILES['pic']['name']);	
	*/
	
	
?>
<?php
if(isset($_POST['save']))
{
	$u=$_POST['usernamesignup'];
	$e=$_POST['emailsignup'];
	$pass=$_POST['passwordsignup'];
	$a=$_POST['agesignup'];
	$query="update customer SET username='$u',email='$e',password='$pass',age=$a where customerid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=display.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}
?>

<html>
    <head>
        <title>Login and Registration Form with HTML5 and CSS3</title>
        <link rel="stylesheet" type="text/css" href="demo.css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" type="text/css" href="animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
		<script type="text/javascript" src="../../../validation/jquery-1.10.2.js">
</script>
<script type="text/javascript" src="../../../validation/validate.js"></script>
<script>
		
	$("document").ready(function(){

	$("#uname").blur(function(){
    //alert("This input fname.");
	test_name("#uname","#msgfname");
});
		$("#save").click(function(){
			var uname,emailsignup,pass,age;
			
			uname = test_name("#uname","#msgfname");
			emailsignup = test_email("#emailsignup","#msgemail");
			pass = test_match("#passwordsignup","#passwordsignup_confirm","#msgpass","#msgpass_confirm");
			//alert(fname);
			
			age= test_num("#agesignup","#msgage");
			if(uname == true && emailsignup == true && pass == true && age == true)
			{
				return true;
				
			}
			else
			{
				return false;
			}
			
		});
	
	});
</script>
	<header>
	</header>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data" action="updat.php"> 
                                <h1> Update for Customer</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >Your username</label>
                                    <input id="uname" name="usernamesignup" value=<?php echo $username; ?> type="text" placeholder="abc123" />									<span id="msgfname"></span>
                                </p>
                                <p> 
                                    <label for="emailsignup" class="youmail"> Your email</label>
                                    <input id="emailsignup" name="emailsignup" type="email" value=<?php echo $email; ?> placeholder="abc@mail.com"/> 
                                <span id="msgemail"></span>
								</p>
								
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >Your password </label>
                                    <input id="passwordsignup" name="passwordsignup"  type="password" value=<?php echo $pass; ?> placeholder="eg. X8df!90EO"/>
                                <span id="msgpass"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Please confirm your password </label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" type="password" value=<?php echo $pass; ?> placeholder="eg. X8df!90EO"/>
									<span id="msgpass_confirm"></span>
                                </p>
								 <p> 
                                 <label for="usernamesignup" class="uname" >Your Age</label>
                                     <input id="agesignup" name="agesignup"  type="text" value=<?php echo $age; ?> placeholder="20" />
									  <span id="msgage"></span>
                                </p>
                                <p class="signin button"> 
									<input type="submit" value="Update" id="save" name="save"/> 
								</p>
</p>
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>