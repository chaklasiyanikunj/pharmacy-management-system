<?php 
include('connection.php');
session_start();
$_SESSION['id']=$_REQUEST['medicinesid'];
$x=$_SESSION['id'];
$query=mysqli_query($con,"select * from medicines where medicinesid='$x'");
$res=mysqli_fetch_assoc($query);

extract($res);

extract($_REQUEST);
	
	$id= $res['medicinesid'];
	$mname = $res['medicinesname'];
	$mtype = $res['medicinestype'];
	$mcost = $res['medicinescost'];
	$mcompany = $res['medicinescompany'];
	$mdescription = $res['medicinesdescription'];
	
	
	
//$qua=implode(",",$chk);
	/*if($img=="")
	
	$query="update users SET name='$n',email='$e',password='$pass',mobile='$m',address='$adds',gender='$gen',qualificaction='$qua',state='$state',dob='$dob' where user_id='$x'";
	mysqli_query($con,$query);
	}
	else
	{
	//delete old pic
	unlink("image/$email/$pic");
	move_uploaded_file($_FILES['pic']['tmp_name'],"image/$email/".$_FILES['pic']['name']);	
	*/
	
	
?>
<?php
if(isset($_POST['save']))
{
	$mname = $_POST['medicinesname'];
	$mtype = $_POST['medicinestype'];
	$mcost = $_POST['medicinescost'];
	$mcompany = $_POST['medicinescompany'];
	$mdescription = $_POST['medicinesdescription'];
	$query="update medicines SET medicinesname='$mname',medicinestype='$mtype',medicinescost=$mcost,medicinescompany='$mcompany' ,medicinesdescription='$mdescription' where medicinesid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managemedicines.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}
?><html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="demo.css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" type="text/css" href="animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	</script>	<script type="text/javascript" src="../../../validation/jquery-1.10.2.js">
</script>
<script type="text/javascript" src="../../../validation/validate.js"></script>
<script>
		
	$("document").ready(function(){

	$("#mname").blur(function(){
    //alert("This input fname.");
	test_name("#mname","#msgfname");
});
		$("#save").click(function(){
			var mname,mtype,mcost,mcompany,mdescription;
			
			mname = test_name("#mname","#msgmname");
			mtype = test_name("#mtype","#msgmtype");
			mcost = test_num("#mcost","msgmcost");
			mcompany = test_name("#mcompany","#msgmcompany");
			mdescription = test_name("#mdescription","#msgmdescription");
			//alert(fname);
			
			if(mname == true && mtype == true && mcost == true && mcompany==true && mdescription==true)
			{
				return true;
				
			}
			else
			{
				return false;
			}
			
		});
	
	});
</script>
	<style>
	</style>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo">
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1>Update Medicines</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >Medicines name</label>
                                    <input id="mname" name="medicinesname" rtype="text" value=<?php echo $mname; ?> placeholder="mysuperusername690" />
                                <span id="msgmname"></span>
								</p>
                                <p> 
                                    <label for="emailsignup" class="youmail" >Medicines type</label>
                                    <input id="mtype" name="medicinestype" value=<?php echo $mtype; ?> placeholder="mysupermail@mail.com"/> 
                                <span id="msgmtype"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >Medicines cost</label>
                                    <input id="mcost" name="medicinescost"  type="text" value=<?php echo $mcost; ?> placeholder="eg. X8df!90EO"/>
                                <span id="msgmcost"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Medicines company </label>
                                    <input id="mcompany" name="medicinescompany"  type="text" value=<?php echo $mcompany; ?> placeholder="eg. X8df!90EO"/>
                                <span id="msgmcompany"></span>
								</p>
								 <p> 
                                 <label for="usernamesignup" class="uname" >Medicines description</label>
                                     <input id="mdescription" name="medicinesdescription" value=<?php echo $mdescription; ?>  type="text" placeholder="20" />
                                <span id="msgmdescription"></span>
								</p>
                                <p class="signin button"> 
									<input id="save" type="submit" value="Update" name="save"/> 
								</p>
</p>
      
</form>
      
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>