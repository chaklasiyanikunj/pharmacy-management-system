<?php 
include('connection.php');
session_start();
$_SESSION['id']=$_REQUEST['syrupid'];
$x=$_SESSION['id'];
$query=mysqli_query($con,"select * from syrup where syrupid='$x'");
$res=mysqli_fetch_assoc($query);

extract($res);

extract($_REQUEST);
	
	$id= $res['syrupid'];
	$sname = $res['syrupname'];
	$stype = $res['syruptype'];
	$scost = $res['syrupcost'];
	$scompany = $res['syrupcompany'];
	$sdescription = $res['syrupdescription'];
	
	
	
//$qua=implode(",",$chk);
	/*if($img=="")
	
	$query="update users SET name='$n',email='$e',password='$pass',mobile='$m',address='$adds',gender='$gen',qualificaction='$qua',state='$state',dob='$dob' where user_id='$x'";
	mysqli_query($con,$query);
	}
	else
	{
	//delete old pic
	unlink("image/$email/$pic");
	move_uploaded_file($_FILES['pic']['tmp_name'],"image/$email/".$_FILES['pic']['name']);	
	*/
	
	
?>
<?php
if(isset($_POST['save']))
{
	$sname = $_POST['syrupname'];
	$stype = $_POST['syruptype'];
	$scost = $_POST['syrupcost'];
	$scompany = $_POST['syrupcompany'];
	$sdescription = $_POST['syrupdescription'];
	$query="update syrup SET syrupname='$sname',syruptype='$stype',syrupcost=$scost,syrupcompany='$scompany' ,syrupdescription='$sdescription' where syrupid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managesyrup.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}
?><html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="demo.css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" type="text/css" href="animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<style>
	</style>
	</script>	<script type="text/javascript" src="../../../validation/jquery-1.10.2.js">
</script>
<script type="text/javascript" src="../../../validation/validate.js"></script>
<script>
		
	$("document").ready(function(){

	$("#sname").blur(function(){
    //alert("This input fname.");
	test_name("sname","#msgsname");
});
		$("#save").click(function(){
			var sname,stype,scost,scompany,sdescription;
			
			sname = test_name("#sname","#msgsname");
			stype = test_name("#stype","#msgstype");
			scost = test_num("#scost","msgscost");
			scompany = test_name("#scompany","#msgscompany");
			sdescription = test_name("#sdescription","#msgsdescription");
			//alert(fname);
			
			if(mname == true && mtype == true && mcost == true && mcompany==true && mdescription==true)
			{
				return true;
				
			}
			else
			{
				return false;
			}
			
		});
	
	});
</script>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo">
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1>Update syrup</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >syrup name</label>
                                    <input id="sname" name="syrupname" required="required" type="text"value=<?php echo $sname; ?>  placeholder="mysuperusername690" />
                                 <span id="msgsname"></span>
								</p>
                                <p> 
                                    <label for="emailsignup" class="youmail" >syrup type</label>
                                    <input id="stype" name="syruptype" value=<?php echo $stype; ?> placeholder="mysupermail@mail.com"/> 
								 <span id="msgstype"></span>
							   </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >syrup cost</label>
                                    <input id="scost" name="syrupcost" required="required" type="text" value=<?php echo $scost; ?> placeholder="eg. X8df!90EO"/>
                                 <span id="msgscost"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >syrup company </label>
                                    <input id="scompany" name="syrupcompany" required="required" type="text" value=<?php echo $scompany; ?> placeholder="eg. X8df!90EO"/>
                                 <span id="msgscompany"></span>
								</p>
								 <p> 
                                 <label for="usernamesignup" class="uname" >syrup description</label>
                                     <input id="sdescription" name="syrupdescription" required="required" type="text" value=<?php echo $sdescription; ?> placeholder="20" />
								 <span id="msgsdescription"></span>
							   </p>
                                <p class="signin button"> 
									<input id="save" type="submit" value="Update" name="save"/> 
								</p>
</p>
      
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>