<?php
include "connection.php";
if(isset($_POST['save']))
{
	session_start();
	$x=$_SESSION['id'];
	$mname = $_POST['medicinesname'];
	$mtype = $_POST['medicinestype'];
	$mcost = $_POST['medicinescost'];
	$mcompany = $_POST['medicinescompany'];
	$mdescription = $_POST['medicinesdescription'];
	$query="update medicines SET medicinesname='$mname',medicinestype='$mtype',medicinescost=$mcost,medicinescompany='$mcompany' ,medicinesdescription='$mdescription' where medicinesid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managemedicines.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}

?>