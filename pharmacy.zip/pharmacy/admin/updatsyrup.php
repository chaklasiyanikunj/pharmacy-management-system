<?php
include "connection.php";
if(isset($_POST['save']))
{
	session_start();
	$x=$_SESSION['id'];
	$sname = $_POST['syrupname'];
	$stype = $_POST['syruptype'];
	$scost = $_POST['syrupcost'];
	$scompany = $_POST['syrupcompany'];
	$sdescription = $_POST['syrupdescription'];
	$query="update syrup SET syrupname='$sname',syruptype='$stype',syrupcost=$scost,syrupcompany='$scompany' ,syrupdescription='$sdescription' where syrupid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managesyrup.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}

?>