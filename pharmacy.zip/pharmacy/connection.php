<?php
$con=mysqli_connect("localhost","root","","pharmacy");
/*
if($con)
{
	echo "connection success";
}
else
{
	echo "not connection";
}*/
?>