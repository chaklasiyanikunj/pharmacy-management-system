
    <?php
    //echo "<select tabindex=\"10\" style=\"width:250px;height:50px;font-size:18px\"; name=\"cmdsubproduct\">";
    $q = $_GET['q'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";
    $sql = "SELECT `syrupname` as name,`syruptype` as type,`syrupcost` as cost ,`syrupdescription` as descr FROM syrup where `syrupname` LIKE '$q%';";
	$conn = new mysqli($servername, $username, $password, $dbname);
    $result = $conn->query($sql);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    if ($result->num_rows > 0)
    {
		
		echo "<table>";	
        while($row = $result->fetch_assoc())
        {
			echo "<table border='1' style='width:40%;float:left;margin-left:2%'>";
			echo "<Tr><th>syrupname</th>
			<th>syruptype</th><th>syrupcost</th><th>syrupdescription</th></tR>";
            echo "<tr>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['type']."</td>";
			echo "<td>".$row['cost']."</td>";
			echo "<td>".$row['descr']."</td>";
			echo "</tr>";
		}
		echo "</table>";
    }
   
    ?>
