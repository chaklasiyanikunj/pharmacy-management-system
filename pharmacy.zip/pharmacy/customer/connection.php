<?php
$con=mysqli_connect("localhost","root","","pharmacy");
if($con)
	//echo "connection success";


	//echo "not connection";
?>