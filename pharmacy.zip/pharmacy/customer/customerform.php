<?php 
include('connection.php');
extract($_REQUEST);
if(isset($save))
{
	$query="select * from customer where email='$emailsignup' ";
	$sql=mysqli_query($con,$query);
	
	//select record
	$row=mysqli_num_rows($sql);	
	if($row==1)
	{
		echo "<h3 style='color:red;margin-left:100px'>This email alredy exists</h3>";
	}
	else
	{
	
	
	$query="insert into customer values('$usernamesignup','$emailsignup','$passwordsignup',$passwordsignup_confirm,now())";
	if(mysqli_query($con,$query))
	{
	echo "<h3 style='color:blue;margin-left:100px'>Records Saved Successfully <br></h3>";	
	}
	else
	{
		echo "Some error while executing query";
		
	}
	
		

	}
	
}




?>
<html>
    <head>
        <title>Login and Registration Form with HTML5 and CSS3</title>
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<header>
	</header>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1> Sign up </h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" data-icon="u">Your username</label>
                                    <input id="usernamesignup" name="usernamesignup" required="required" type="text" placeholder="mysuperusername690" />
                                </p>
                                <p> 
                                    <label for="emailsignup" class="youmail" data-icon="e" > Your email</label>
                                    <input id="emailsignup" name="emailsignup" required="required" type="email" placeholder="mysupermail@mail.com"/> 
                                </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" data-icon="p">Your password </label>
                                    <input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Please confirm your password </label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p class="signin button"> 
									<input type="submit" value="Sign up" name="save"/> 
								</p>
</p>
                                <p class="change_link">  
									Already a member ?
									<a href="login.html" class="to_register"> Go and log in </a>
								</p>
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>