<?php
if (session_status() == PHP_SESSION_NONE) 
 {
        session_start();
		//echo "Hello";
		
 }
     if(!isset($_SESSION['email']))
	 {
		 header("location:..\login.php");
	 }
?>
<?php 
include('connection.php');
extract($_REQUEST);

if(isset($_POST['save']))
{

	$fname = $_POST['fullname'];
	$mnumber = $_POST['mobilenumber'];
	$pcode = $_POST['pincode'];
	$hno = $_POST['houseno'];
	$a = $_POST['area'];
	$lmark = $_POST['landmark'];
	$c = $_POST['city'];
	$s = $_POST['state'];
	
	//$sql = "insert into customer(username,email,password,confirmpassword) values('$uname','$eml','$pswd','$pswd2')";
	//mysqli_query($con,$sql);
	
	$query = "select * from payment where fullname='$fname'";
	$sql = mysqli_query($con,$query);
	
	//select record
	$row = mysqli_num_rows($sql);	
	if($row==1)
	{
		//echo "<h3 style='color:red;margin-left:100px'>This email alredy exists</h3>";
	}
	else
	{
		
		$query = "insert into payment(fullname,mobilenumber,pincode,houseno,area,landmark,city,state) values('$fname',$mnumber,$pcode,'$hno','$a','$lmark','$c','$s')";
		if(mysqli_query($con,$query))
		{
			//echo "<h3 style='color:blue;margin-left:100px'>Records Saved Successfully <br></h3>";	
		}
		else
		{
			echo "Some error while executing query";
		}
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>pharmacy management system</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.con{
position:absolute;
margin-top:50px;
width:74%;
background-color:#C0C1FA;
left:140px;
}
 input{
	  border-radius:10px;
	  width:300px;
  }
  
  #block{
  margin-left:30%;
  height:700px;
  width:500px;
  background-color:#CCCCCC;  
  }
  input .save
  {
  	width:150px;
  }
</style>
</head>
<body >
<div id="block">
<form id="form1" method="post" enctype="multipart/form-data">
<center>
<h1>Shipping Details</h1>
<table class="ne" align="center">
<tr>
				<td><b>Full name :<br /><input type="text" name="fullname" style=" padding:7px;" ></td>
</tr>
	<tr>
				<td><br><b>Mobile number : <br /> <input type="text" name="mobilenumber" style=" padding:7px;"></td>
	</tr>
	<tr>
				<td><br /><b>Pincode : <br /> <input type="text" name="pincode" style=" padding:7px;"></td>
	</tr>
	<tr>
				<td><br /><b>Flat, House no., Building, Company, Apartment : <br /><input type="text" name="houseno"  style=" padding:7px;"></td>
	</tr>
	<tr>
				<td><br /><b>Area, Colony, Street, Sector, Village : <br /><input type="text" name="area" style=" padding:7px;"></td>
	</tr>
	<tr>
				<td><br /><b>Landmark e.g. near apollo hospital : <br /><input type="text" name="landmark"  style=" padding:7px;"></td>
	</tr>
<tr>
				<td><br /><b>Town/City : <br /><input type="text" name="city" style=" padding:7px;"></td>
	</tr>
<tr>
				<td><br /><b>State : <br /><input type="text" name="state" style=" padding:7px;"></td>
	</tr>
	<tr>
	<td><input type="submit" style="margin-top:20px;width:150x;height:30px;background-color:#000000;color:#FFFFFF;" value="submit" name="save"/></td>
	</tr>
		
</table>
</center>
</form>
</div>
</body>
</html>

