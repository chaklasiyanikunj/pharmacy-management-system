<?php
if (session_status() == PHP_SESSION_NONE) 
 {
        session_start();
		//echo "Hello";
		
 }
     if(!isset($_SESSION['email']))
	 {
		 header("location:..\login.php");
	 }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>pharmacy management system</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.con{position:absolute;
margin-top:50px;
width:74%;
background-color:#C0C1FA;
left:140px;
}
a{
	color:yellow;
}
input
{
font-size:50px;
}
body {
      position: relative; 
  }
  .affix {
      top:0;
      width: 100%;
      z-index: 9999 !important;
  }
  .navbar {
      margin-bottom: 0px;
  }

  .affix ~ .container-fluid {
     position: relative;
     top: 50px;
  }
  #section1 {padding-top:50px;height:500px;color: #fff; background-color: #1E88E5;}
  #section2 {padding-top:50px;height:500px;color: #fff; background-color: #673ab7;}
  #section3 {padding-top:50px;height:500px;color: #fff; background-color: #ff9800;}
  #section41 {padding-top:50px;height:500px;color: #fff; background-color: #00bcd4;}
  #section42 {padding-top:50px;height:500px;color: #fff; background-color: #009688;}
  </style>
</style>
</head>

<body bgcolor="#CCCCCC">
<nav class="navbar navbar-inverse" data-spy="affix">
  <div class="container-fluid">
	<div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">PhaemacyManagementSystem</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
	<li><a href="index.php">Purchase</a></li>
	<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Search<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="medicine.php">Medicine</a></li>
              <li><a href="syrup.php">Syrup</a></li>
            </ul>
          </li>
	<li><a href="help.php">Help</a></li>
	<li><a href="logout.php">LogOut</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>  
<br><br><br>
<center>
<form>
<p><marquee>Buy syrup online. It's easy as its name.</marquee>
<h3>Buying syrup was never this easy. Stay at the comfort of your home and get syrup delivered to your door- step.</h3>
<h3>And it's double the gain when our discounted rates offer you the benefit of extra savings!</h3>
<h1>Search Syrup<h1></p>
<input type=" text"  id="txtsearch" placeholder="Eg:TUSQ DX 100ml" name="txt1" style="text-align:left;
		hight:60px; width:800px;"  />		
<input type="button" onclick="search()" name="txt1" value="Search"  style="text-align:center; color:#FFFFFF; font-weight:bold; font-size:50px; background-color:#0000CC; margin-top:20px; height:75px; width:250px; border-radius:50px 50px 50px 50px;"/></h3><br /><br />
</center>
<div id="divtable">

</div>
 <!--  Ajax -->

<script type="text/javascript" language="javavascript">
function search() {
	 var str=document.getElementById("txtsearch").value;
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("divtable").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","ajaxsubproduct1.php?q="+str,true);
        xmlhttp.send();
    }
    }
    </script>
    <!-- Ajax-->
</body>
</html>
