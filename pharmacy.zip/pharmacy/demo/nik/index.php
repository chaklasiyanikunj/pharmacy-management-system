<html>
<head>
<title>paper cup</title>
</head>
<body>
<h1>Registration from</h1>
First Name:<input type="text" name="firstname" />
Last Name:<input type="text" name="lastname" />
</br>
</br>
Gender:<input type="radio" name="Male" value="male"/>Male
<input type="radio" name="FeMale" value="Female"/>FeMale
</br>
</br>
Email:<input type="text" name="email" />
</br>
</br>
<input type="button" value="submit" name="submit" />

</body>
</html>