<?php
include "connection.php";
if(isset($_POST['save']))
{
	$u=$_REQUEST['email'];
	$p=$_REQUEST['password'];
	$c=$_REQUEST['confirmpassword'];
	$query="update customer SET password='$p',confirmpassword='$c' where email='$u'";
	mysqli_query($con,$query);
	header( "refresh:2;url=login.php" ); 
	echo '<h3>Password changed successfully</h3>'; 

	
}

?>
<html>
    <head>
        <title>Login and Registration Form with HTML5 and CSS3</title>
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<header>
	</header>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">

                            <form  method="post" action="send_mail.php" autocomplete="on"> 
                                <h1>Reset Password</h1> 
                                <p> 
                                    <label for="username" class="uname" data-icon="u" > Your email or username </label>
                                    <input id="username" name="email" required="required" type="text" placeholder="abc@gmail.com"/>
                                </p>
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p"> Your password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="123456" /> 
                                </p>
<p> 
                                    <label for="confirmpassword" class="youpasswd" data-icon="p"> Your Confirm password </label>
                                    <input id="cofirmpassword" name="confirmpassword" required="required" type="password" placeholder="123456" /> 
                                </p>
                                <p class="keeplogin"> 
									<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
									<label for="loginkeeping">Keep me logged in</label>
								</p>
                                <p class="login button"> 
                                    <input type="submit" value="Reset" name="save" /> 
								</p>
                                <p class="change_link">
									Not a member yet ?	
	<a href="login.php" class="to_register">Now Login</a>								</p>
                            </form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>