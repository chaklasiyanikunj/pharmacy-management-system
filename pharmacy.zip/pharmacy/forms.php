<?php 
include('connection.php');
extract($_REQUEST);

if(isset($_POST['save']))
{

	$uname = $_POST['usernamesignup'];
	$eml = $_POST['emailsignup'];
	$pswd = $_POST['passwordsignup'];
	$pswd2 = $_POST['passwordsignup_confirm'];
	$age = $_POST['agesignup'];
	
	//$sql = "insert into customer(username,email,password,confirmpassword) values('$uname','$eml','$pswd','$pswd2')";
	//mysqli_query($con,$sql);
	
	$query = "select * from customer where emailsignup='$eml' ";
	$sql = mysqli_query($con,$query);
	
	//select record
	//$row = mysqli_num_rows($sql);	
	/*if($row==1)
	{
		//echo "<h3 style='color:red;margin-left:100px'>This email alredy exists</h3>";
	}
	else
	{*/
		$query = "insert into customer(username,email,password,confirmpassword,age) values('$uname','$eml','$pswd','$pswd2',$age)";
		if(mysqli_query($con,$query))
		{
			echo "<script>alert('Data Inserted Successfully');</script>";
			//echo "<h3 style='color:blue;margin-left:100px'>Records Saved Successfully <br></h3>";	
		}
		else
		{
			echo "<script>alert('Some error while executing query');</script>";
		}
	//}
}
?>

<html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<script type="text/javascript" src="../../validation/jquery-1.10.2.js">
</script>
<script type="text/javascript" src="../../validation/validate.js"></script>
<script>
		
	$("document").ready(function(){

	$("#uname").blur(function(){
    //alert("This input fname.");
	test_name("#uname","#msgfname");
});
		$("#save").click(function(){
			var uname,emailsignup,pass,age;
			
			uname = test_name("#uname","#msguname");
			emailsignup = test_email("#emailsignup","#msgemail");
			pass = test_match("#passwordsignup","#passwordsignup_confirm","#msgpass","#msgpass_confirm");
			//alert(fname);
			
			age= test_num("#agesignup","#msgage");
			if(uname == true && emailsignup == true && pass == true && age == true)
			{
				return true;
				
			}
			else
			{
				return false;
			}
			
		});
	
	});
</script>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo">
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1> Sign up for Customer</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" data-icon="u">Your username</label>
                                    <input id="uname" name="usernamesignup" type="text" placeholder="nikunj chaklasiya" />									<span id="msgfname"></span>
                                <span id="msguname"></span>
								</p>
                                <p> 
                                    <label for="emailsignup" class="youmail" data-icon="e" > Your email</label>
                                    <input id="emailsignup" name="emailsignup" type="email" placeholder="nikunj@mail.com"/> 
                                <span id="msgemail"></span>
								</p>
								
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" data-icon="p">Your password </label>
                                    <input id="passwordsignup" name="passwordsignup"  type="password" placeholder="123456"/>
                                <span id="msgpass"></span>
								</p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Please confirm your password </label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" type="password" placeholder="123456"/>
									<span id="msgpass_confirm"></span>
                                </p>
								 <p> 
                                 <label for="usernamesignup" class="uname" data-icon="u">Your Age</label>
                                     <input id="agesignup" name="agesignup"  type="text" placeholder="20" />
									  <span id="msgage"></span>
                                </p>
                                <p class="signin button"> 
									<input type="submit" value="Sign up" id="save" name="save"/> 
								</p>
</p>
                                <p class="change_link">  
									Already a member ?
									<a href="login.php" class="to_register"> Go and log in </a>
								</p>
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>