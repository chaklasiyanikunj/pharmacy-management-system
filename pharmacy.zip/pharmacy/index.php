<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style>
.con{position:absolute;
margin-top:50px;
width:74%;
background-color:#C0C1FA;
left:140px;
}
.container {
    position: relative;
    width: 100%;
    max-width: 4000px;
}

.container img {
    width: 3000px;
    height: 550px;
}
a{
	color:yellow;
}
input
{
font-size:50px;
}
</style>
</head>

<body bgcolor="#CCCCCC">
<h1 style="color:#FFFFFF; background-color:#333333; font-weight:bold; padding:10px;">Pharmacy Management System<t>&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="login.php" align="right">Login</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="menu.php" align="right">SignUp</a></h1>
<div class="container">
  <img src="img_snow.jpeg" alt="Snow" style="width:100%">
  </div>
</body>
</html>
