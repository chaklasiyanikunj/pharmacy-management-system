<?php
	session_start();
	$db=mysqli_connect("localhost","root","","pharmacy");

	if (isset($_POST['login']))
	{
		$email = $_POST['email'];
		$pswd = $_POST['password']; 
		//$pswd = md5($pswd);
		
		$sql = "SELECT * FROM customer WHERE email='$email' AND password='$pswd'";
		
		$sqli = "SELECT * FROM medicalstore WHERE email='$email' AND password='$pswd'";
		$result = mysqli_query($db,$sql);
		$res = mysqli_query($db,$sqli);
		if (mysqli_num_rows($result) == 1)
		{
			$_SESSION['email'] = $email;
			//echo "<script type=text/javascript>windows.location.href('customer\giveorder.php');</script>";
			header("location:customer\index.php");
		}
		else if (mysqli_num_rows($res) == 1)
		{
			$_SESSION['email'] = $email;
			header("location:medicalstore\index.php");
		}
		else if ($email=="admin" && $pswd=="admin")
		{
			$_SESSION['email'] = $email;
			header("location:admin\managecustomer.php");
		}
		else
		{
			
			echo "<script>alert('The username or password you entered is incorrect!');</script>";
		}
	}
?>
<html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<header>
	</header>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <form action="login.php" autocomplete="on" method="post"> 
                                <h1>Log in</h1> 
                                <p> 
                                    <label for="username" class="uname" data-icon="u" > Your email </label>
                                    <input id="username" name="email" required="required" type="text" placeholder="abc@gmail.com"/>
                                </p>
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p"> Your password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="123456" /> 
                                </p>
                                <p class="keeplogin"> 
									<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
									<label for="loginkeeping">Keep me logged in</label>
								</p>
                                <p class="login button"> 
                                    <input type="submit" value="Login" name="login" /> 
								</p>
                                <p class="change_link">
									Not a member yet ?
	<a href="forms.php" class="to_register">Sign Up</a>							
	<a href="forgetpassword.php" class="to_register">Reset Password</a>								</p>
                            </form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>