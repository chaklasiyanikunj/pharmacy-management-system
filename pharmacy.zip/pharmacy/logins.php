<?php
	session_start();
	$db=mysqli_connect("localhost","root","","pharmacy");

	if (isset($_POST['login']))
	{
		$uname = $_POST['username'];
		$pswd = $_POST['password']; 
		$pswd = md5($pswd);
		
		$sql = "SELECT * FROM medicalstore WHERE username='$uname' AND password='$pswd'";
		$result = mysqli_query($db,$sql);
		
		if (mysqli_num_rows($result) == 1)
		{
			$_SESSION['username'] = $username;
			header("location:medicalstore.php");
		}
		else
		{
			$_SESSION['message'] = "The username or password you entered is incorrect!";
		}
	}
?>
<html>
    <head>
        <title>Login and Registration Form with HTML5 and CSS3</title>
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<header>
	</header>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo" >
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <form action="medicalstore\menu.php" autocomplete="on" method="post"> 
                                <h1>Log in</h1> 
                                <p> 
                                    <label for="username" class="uname" data-icon="u" > Your email or username </label>
                                    <input id="username" name="username" required="required" type="text" placeholder="myusername or mymail@mail.com"/>
                                </p>
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p"> Your password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="eg. X8df!90EO" /> 
                                </p>
                                <p class="keeplogin"> 
									<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
									<label for="loginkeeping">Keep me logged in</label>
								</p>
                                <p class="login button"> 
                                    <input type="submit" value="Login" name="login" /> 
								</p>
                                <p class="change_link">
									Not a member yet ?
	<a href="forms.php" class="to_register">Sign Up</a>							
	<a href="forgetpassword.php" class="to_register">Forget Password</a>								</p>
                            </form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>