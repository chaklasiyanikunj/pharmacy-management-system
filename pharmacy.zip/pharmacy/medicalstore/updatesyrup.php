<?php 
include('connection.php');
session_start();
$_SESSION['id']=$_REQUEST['syrupid'];
$x=$_SESSION['id'];
$query=mysqli_query($con,"select * from syrup where syrupid='$x'");
$res=mysqli_fetch_assoc($query);

extract($res);

extract($_REQUEST);
	
	$id= $res['syrupid'];
	$sname = $res['syrupname'];
	$stype = $res['syruptype'];
	$scost = $res['syrupcost'];
	$scompany = $res['syrupcompany'];
	$sdescription = $res['syrupdescription'];
	
	
	
//$qua=implode(",",$chk);
	/*if($img=="")
	
	$query="update users SET name='$n',email='$e',password='$pass',mobile='$m',address='$adds',gender='$gen',qualificaction='$qua',state='$state',dob='$dob' where user_id='$x'";
	mysqli_query($con,$query);
	}
	else
	{
	//delete old pic
	unlink("image/$email/$pic");
	move_uploaded_file($_FILES['pic']['tmp_name'],"image/$email/".$_FILES['pic']['name']);	
	*/
	
	
?>
<?php
if(isset($_POST['save']))
{
	$sname = $_POST['syrupname'];
	$stype = $_POST['syruptype'];
	$scost = $_POST['syrupcost'];
	$scompany = $_POST['syrupcompany'];
	$sdescription = $_POST['syrupdescription'];
	$query="update syrup SET syrupname='$sname',syruptype='$stype',syrupcost=$scost,syrupcompany='$scompany' ,syrupdescription='$sdescription' where syrupid='$x'";
	mysqli_query($con,$query);
	header( "refresh:2;url=managesyrup.php" ); 
	echo '<h3>Records updated successfully</h3>'; 

}
?><html>
    <head>
        <title>pharmacy management system</title>
        <link rel="stylesheet" type="text/css" href="demo.css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" type="text/css" href="animate-custom.css" />
	<link type="text/css" href="header.css" rel="stylesheet" />
	<style>
	</style>
    </head>
    <body>
        <div class="container">
            <section>				
                <div id="container_demo">
		<a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
		<a class="hiddenanchor" id="toforget"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                    <form method="post" enctype="multipart/form-data"> 
                                <h1>Update syrup</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >syrup name</label>
                                    <input id="usernamesignup" name="syrupname" value="<?php echo $sname; ?>"required="required" type="text" placeholder="mysuperusername690" />
                                </p>
                                <p> 
                                    <label for="emailsignup" class="youmail" >syrup type</label>
                                    <input id="emailsignup" name="syruptype" value="<?php echo $stype; ?>" placeholder="mysupermail@mail.com"/> 
                                </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >syrup cost</label>
                                    <input id="passwordsignup" name="syrupcost" required="required"value="<?php echo $scost; ?>" type="text" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >syrup company </label>
                                    <input id="passwordsignup_confirm" name="syrupcompany" required="required" value="<?php echo $scompany; ?>"type="text" placeholder="eg. X8df!90EO"/>
                                </p>
								 <p> 
                                 <label for="usernamesignup" class="uname" >syrup description</label>
                                     <input id="usernamesignup" name="syrupdescription" required="required" value="<?php echo $sdescription; ?>"type="text" placeholder="20" />
                                </p>
                                <p class="signin button"> 
									<input type="submit" value="update" name="save"/> 
								</p>
</p>
      
</form>
                        </div>
                </div>  
            </section>
        </div>
    </body>
</html>