<html>
<body>
<form name="f1" method="post" action="nikunj.php">
<table>
<tr>
<td>Username</td>
<td><input type="text" name="un"></td>
</tr>
<tr>
<td>password</td>
<td><input type="password" name="pass"></td>
<tr>
<td><input type="radio" name="user" value="user" checked="true">User</td>
<td><input type="radio" name="user" value="admin">Admin</td>
</tr>
<tr>
<td> <input type="submit" value="submit" name="submit"></td>
</tr>
</form>
</table>
</body>
</html>
<?php
if(isset($_POST['submit']))	
{
	$u=$_POST['un'];
	$p=$_POST['pass'];
	$t=$_POST['user'];
	$con=mysql_connect("localhost","root","") or die(mysql_error());
	$db=mysql_select_db("test");
	if($t=="user")
	{
		$sql=mysql_query("Select * from user where Username='$u' and Type='$t'")or die(mysql_error());
		$res=mysql_num_rows($sql);
		if($res>0)
			echo "Successful";
		else	
			echo "UnSuccessful";
	}
	elseif($t=="admin")
	{
		$sql=mysql_query("Select * from user where Username='$u' and Type='$t'");
		$res=mysql_num_rows($sql);
		if($res>0)
			echo "Successful";
		else	
			echo "UnSuccessful";
	}
	else
		echo "Invalid Username and Password";
}
?>