<?php
	$mailto = $_POST['mail_to'];
	$mailSub = $_POST['mail_sub'];
	$mailMsg = $_POST['mail_msg'];
	require 'PHPMailer-master/PHPMailerAutoload.php';
	$mail = new PHPMailer;
	$mail ->IsSmtp();
	$mail ->SMTPDebug =1;
	$mail ->SMTPAuth = true;
	$mail ->SMTSecure = 'ss1';
	$mail ->Host = "smtp.gmail.com";
	$mail ->Port = 465;
	$mail ->IsHTML(true);
	$mail ->username = "chaklasiyanikunj@gmail.com";
	$mail ->Password = "9944@nikunj";
	$mail ->SetFrom("chaklasiyanikunj@gmail.com");
	$mail ->Subject =$mailSub;
	$mail ->Body =$mailMsg;
	$mail ->AddAddress($mailto);
	
	if(!$mail->send())
	{
		echo "mail not send";
	}
	else
	{
		echo "mail send";
	}
	
	